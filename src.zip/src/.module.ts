import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoutingModule } from './-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RoutingModule
  ]
})
export class Module { }
