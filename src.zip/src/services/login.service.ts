import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from 'src/app/model/user';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private _httpClient:HttpClient) { }

  checkUserExistence(userObj:any):Observable<any>{

    return this._httpClient.get("https://daimalerblog2019-cf.cfapps.io/findboauserbyname/"+userObj.userName);

  }

  //https://daimalerblog2019-cf.cfapps.io/findallboausers
  //https://daimalerblog2019-cf.cfapps.io/findboauserbyname/admin

}
