import { BrowserModule } from '@angular/platform-browser';
import { NgModule} from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatIconModule, MatTableModule, MatPaginatorModule, MatSortModule} from '@angular/material';
import {MatButtonModule} from '@angular/material/button';
import { HttpClientModule } from '@angular/common/http';
import { LoginService } from 'src/services/login.service';
import { AuthService } from 'src/services/auth.service';
import { MenuService } from 'src/services/menu.service';
import { HomeComponent } from './home/home.component';
import {TieredMenuModule} from 'primeng/tieredmenu';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { RequestComponent } from './request/request.component';
import { ChequeComponent } from './cheque/cheque.component';
import { AddressComponent } from './address/address.component';
import { TransactionComponent } from './transaction/transaction.component';
import {MatDialogModule} from '@angular/material/dialog';

import { EditviewComponent } from './transaction/editview/editview.component';
import { EditComponent } from './transaction/edit/edit.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AccountsummaryComponent,
    RequestComponent,
    ChequeComponent,
    AddressComponent,
    TransactionComponent,
    
    EditviewComponent,
    EditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatIconModule,
    FormsModule,
    MatButtonModule,
    HttpClientModule,
    TieredMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule
  ],
  entryComponents:[EditviewComponent,EditComponent],
  providers: [LoginService,AuthService,MenuService],
  bootstrap: [AppComponent]
})
export class AppModule { }
