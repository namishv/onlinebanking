import { Component, OnInit } from '@angular/core';
import {User} from '../model/user';
import { LoginService } from 'src/services/login.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/services/auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  })
export class LoginComponent implements OnInit {

  user=new User("admin","admin123");

  constructor(private _loginService:LoginService, private _router:Router, private _authService:AuthService) 
  { 

  }



  ngOnInit() {

  }



  login(event)

  {

    event.preventDefault();

    console.log(this.user);
    this._loginService.checkUserExistence(this.user).subscribe(response=>{
      console.log(response);
      if(response.email!=null){
        this._authService.token = response.email;
      }
      if(this._authService.IsLoggedIn){
        this._router.navigate(["/Home"]);
      }
      
      else{
        this._router.navigate(["/Login"]);
      }
    });

  }

  newUser() {

    this.user = new User('','');
    

  }

}
