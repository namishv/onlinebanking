import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rtgs',
  templateUrl: './rtgs.component.html',
  styleUrls: ['./rtgs.component.css']
})
export class RtgsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
