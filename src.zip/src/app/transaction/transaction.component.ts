import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {MatTableDataSource} from "@angular/material/table";
//@ts-ignore
import * as data from '../../opec.json';
import { MatDialog } from '@angular/material';
import { EditviewComponent } from './editview/editview.component';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit , AfterViewInit{
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  displayedColumns:string[] = ['0','1','edit','delete'];
  //tableData:any;
  tableSource = new MatTableDataSource();
  constructor(private _dialog:MatDialog) { }

  ngOnInit() {
    console.log(data.dataset.data);
    //this.tableData = data.dataset.data;
    this.tableSource.data = data.dataset.data;
  }

  ngAfterViewInit(){
    this.tableSource.paginator = this.paginator;
    this.tableSource.sort = this.sort;
  }

  openDialog(obj:any){
    const dialogRef =this._dialog.open(EditviewComponent,{
      width: '500px',
      data:{
        date:obj[0],
        value:obj[1]

      }
    });

    dialogRef.afterClosed().subscribe(result =>{
      console.log("this dialog was closed");
      console.log(result);
    })

  }

}
