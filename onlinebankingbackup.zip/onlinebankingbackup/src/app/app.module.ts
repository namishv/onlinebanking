import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector} from '@angular/core';
import { createCustomElement} from '@angular/elements';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatIconModule, MatTableModule, MatPaginatorModule, MatSortModule, MatListModule, MatSnackBarModule} from '@angular/material';
import {MatButtonModule} from '@angular/material/button';
import { HttpClientModule } from '@angular/common/http';
import { LoginService } from 'src/services/login.service';
import { AuthService } from 'src/services/auth.service';
import { MenuService } from 'src/services/menu.service';
import { HomeComponent } from './home/home.component';
import {TieredMenuModule} from 'primeng/tieredmenu';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { RequestComponent } from './request/request.component';
import { ChequeComponent } from './cheque/cheque.component';
import { AddressComponent } from './address/address.component';
import { TransactionComponent } from './transaction/transaction.component';
import {MatDialogModule} from '@angular/material/dialog';

import { EditviewComponent } from './transaction/editview/editview.component';
import { EditComponent } from './transaction/edit/edit.component';
import { FooterComponent } from './footer/footer.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { OAuthModule } from 'angular-oauth2-oidc';
import { RegisterComponent } from './register/register.component';
import { EqualValidator } from './register/matchvalidator';
import {UserService} from '../services/user.service';
import { SnackbarComponent } from './snackbar/snackbar.component'




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AccountsummaryComponent,
    RequestComponent,
    ChequeComponent,
    AddressComponent,
    TransactionComponent,
  RegisterComponent,
    EditviewComponent,
    EditComponent,
    FooterComponent,
    EqualValidator,
    SnackbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatIconModule,
    FormsModule,
    MatButtonModule,
    HttpClientModule,
    TieredMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatListModule,
    ReactiveFormsModule,
    MatSnackBarModule,
    OAuthModule.forRoot(),
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  entryComponents:[EditviewComponent,EditComponent,FooterComponent],
  providers: [LoginService,AuthService,MenuService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor(private injector:Injector){
    const customElement =  createCustomElement(FooterComponent,
      {injector});
      customElements.define('boa-footer',customElement);

  }
}
