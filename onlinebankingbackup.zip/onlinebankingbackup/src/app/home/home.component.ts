import { Component, OnInit } from '@angular/core';
import { MenuService } from 'src/services/menu.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  data : any;
  constructor(private _menuService:MenuService) { }

  ngOnInit() {
    this.data = this._menuService.getMenuItems();
  }

}
