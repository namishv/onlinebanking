import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ImpsComponent } from './imps/imps.component';
import { NeftComponent } from './neft/neft.component';
import { RtgsComponent } from './rtgs/rtgs.component';


const routes: Routes = [{
  path:"Neft", component:NeftComponent
},
{
  path:"Imps", component:ImpsComponent
},
{
  path:"Rtgs", component:RtgsComponent
}
 ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FundtransferRoutingModule { }
