import { Menu, SubMenu } from "./menu";


export let menuData: Menu[] = [new Menu('Account Summary', 'pi pi-fw pi-plus', 'AccountSummary', [new SubMenu('Transaction', 'pi pi-arrow-right', 'AccountSummary/Transaction')]),
new Menu('Request', 'pi pi-fw pi-plus', 'Requests', [new SubMenu('Cheque Request', 'pi pi-arrow-right', 'Requests/Cheque'), new SubMenu('Adress Change', 'pi pi-arrow-right', 'Requests/Address')]),
new Menu('Fund Transfer', 'pi pi-fw pi-plus', 'Fundtransfer', [new SubMenu('RTGS', 'pi pi-arrow-right', 'Fundtransfer/Rtgs'), new SubMenu('NEFT', 'pi pi-arrow-right', 'Fundtransfer/Neft'), new SubMenu('IMPS', 'pi pi-arrow-right', 'Fundtransfer/Imps')]),
];
