import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FundtransferRoutingModule } from './fundtransfer-routing.module';
import { ImpsComponent } from './imps/imps.component';
import { RtgsComponent } from './rtgs/rtgs.component';
import { NeftComponent } from './neft/neft.component';



@NgModule({
  declarations: [ImpsComponent,
    RtgsComponent,
    NeftComponent
  ],
  imports: [
    CommonModule,
    FundtransferRoutingModule
  ]
})
export class FundtransferModule { }
